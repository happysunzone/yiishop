<?php

return [
    /* appfront base theme dir   */
    'appadminBaseTheme'     => '@fecshop/app/appadmin/theme/base/default',
    'appadminBaseLayoutName'=> 'main_admin.php',
    'appName'               => 'appadmin',

];