<?php

return [
    /* apphtml5 base theme dir   */
    'apphtml5BaseTheme'    => '@fecshop/app/apphtml5/theme/base/html5',
    'apphtml5BaseLayoutName'=> 'main.php',
    'appName' => 'apphtml5',

];
